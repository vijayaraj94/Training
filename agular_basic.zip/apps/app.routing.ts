/* [ Core Library ] */
import { NgModule, Component, OnInit } from '@angular/core';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
/* [ Get Constant ] */
import { CONST } from './appconstant';
/* [ Custom Component ] */
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { JobsearchComponent } from './components/jobsearch/jobsearch.component';
import { JobsearchresultComponent } from './components/jobsearchresult/jobsearchresult.component';
import { SigninComponent } from './components/signin/signin.component';
import { SignupComponent } from './components/signup/signup.component';
import { AdminpageComponent } from './components/adminpage/adminpage.component';
import { LeftmenuComponent } from './components/leftmenu/leftmenu.component';
import { ProfileComponent } from './components/profile/profile.component';
import { AcademicComponent } from './components/academic/academic.component';
import { ExperienceComponent } from './components/experience/experience.component';

/* [ Routing ] */
const appRoutes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full' },
  { path: CONST.ROUTES.SIGNUP, component: SignupComponent },
  { path: CONST.ROUTES.SIGNIN, component: SigninComponent },
  { path: CONST.ROUTES.ADMINPAGE, component: AdminpageComponent,
    children: [
      { path: '', redirectTo: 'profile', pathMatch: 'full' },
      { path: 'profile', component: ProfileComponent },
      { path: 'academic', component: AcademicComponent },
      { path: 'experience', component: ExperienceComponent },
    ]
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false, useHash: false } /* [ For debugging ourpose only ] */
    )
  ],
  exports: [RouterModule]
})

export class AppRoutingModule { }

export const routingComponents = [
  HomeComponent,
  HeaderComponent,
  FooterComponent,
  JobsearchComponent,
  JobsearchresultComponent,
  SigninComponent,
  SignupComponent,
  AdminpageComponent,
  LeftmenuComponent,
  ProfileComponent,
  AcademicComponent,
  ExperienceComponent
];
