export const CONST = Object.freeze({
  ROUTES :{
    SIGNUP : 'register',
    SIGNIN : 'login',
    ADMINPAGE : 'admin',
    LEFTMENU : [{
        value_1:'profile',
        title_1 : 'Profile'
      },{
        value_2 : 'academic',
        title_2 : 'Academic'
      },{
        value_3 : 'experience',
        title_3 : 'Experience'
    }],
  }  
});
