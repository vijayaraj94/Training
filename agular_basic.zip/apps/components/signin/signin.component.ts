import { Component } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
  providers : [HeaderComponent,FooterComponent]
})
export class SigninComponent extends AppComponent {
  pageTitle = 'Home';

  signin : object = {
    email : '',
    password : '',
  }


  logIn(value : any, valid:boolean) {
    let isvalid : boolean = false;
    if(valid === true){
        if(value.email === 'test@gmail.com' && value.password === 'test'){
          isvalid = true;
        } else if(value.email === 'test1@gmail.com' && value.password === 'test1'){
          isvalid = true;
        }
        if(isvalid === true){
          this.router.navigateByUrl(this.getConst('ROUTES.ADMINPAGE'));
        } else {
          // Error Message
          alert("Please enter correct Username and Password");
        }

    }
  }
}
