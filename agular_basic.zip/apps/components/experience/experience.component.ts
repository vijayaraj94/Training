import { Component,  OnInit } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css'],
})
export class ExperienceComponent extends AppComponent OnInit {

public editExp: FormGroup;
experience : Object = {};
public submitted: boolean=false;

ngOnInit() {
  this.editExp = new FormGroup({
      companyName: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5), <any>Validators.maxLength(50)]),
  });
  }

submitExperience(value : any,valid : boolean){
  if(valid === true){
  console.log('isvalid',valid);
  console.log('value',value);
  }
}
get companyName() { return this.editExp.get('companyName');
}
}
