import { Component } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';
import { LeftmenuComponent } from '../leftmenu/leftmenu.component';
import { ProfileComponent } from '../profile/profile.component';
import { AcademicComponent } from '../academic/academic.component';



@Component({
  selector: 'app-adminpage',
  templateUrl: './adminpage.component.html',
  styleUrls: ['./adminpage.component.css'],
  providers : [HeaderComponent,FooterComponent,LeftmenuComponent,ProfileComponent,AcademicComponent]
})
export class AdminpageComponent extends AppComponent {
  pageTitle = 'Angular Js';
}
