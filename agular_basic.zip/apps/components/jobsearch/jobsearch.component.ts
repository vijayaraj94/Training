import { Component } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { JobsearchresultComponent } from '../jobsearchresult/jobsearchresult.component';
@Component({
  selector: 'app-jobsearch',
  templateUrl: './jobsearch.component.html',
  styleUrls: ['./jobsearch.component.css'],
  providers : [JobsearchresultComponent]
})
export class JobsearchComponent extends AppComponent {
  pageTitle = 'Angular Js';


}
