import { Component,  OnInit } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent extends AppComponent implements OnInit {
    public editForm: FormGroup;
    profile : Object = {};
    public submitted: boolean=false;

    ngOnInit() {
      this.editForm = new FormGroup({
          name: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5), <any>Validators.maxLength(15)]),
          age: new FormControl('', [<any>Validators.required, Validators.min(21),Validators.max(90)]),
          email: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
          years: new FormControl('', [<any>Validators.required, Validators.min(1),Validators.max(5)]),
          months:new FormControl('', [<any>Validators.required, Validators.min(1),Validators.max(12)]),
          phone: new FormControl('', [<any>Validators.required, <any>Validators.minLength(9), <any>Validators.maxLength(10)]),
          located: new FormControl('', <any>Validators.required),
          address: new FormControl('', <any>Validators.required)
      });
      }

    submitProfile(value : any,valid : boolean){
      if(valid === true){
      console.log('isvalid',valid);
      console.log('value',value);
      }
    }
    get name() { return this.editForm.get('name'); }
    get age() { return this.editForm.get('age'); }
    get email() { return this.editForm.get('email'); }
    get years() { return this.editForm.get('years'); }
    get months() { return this.editForm.get('months'); }
    get phone() { return this.editForm.get('phone'); }
    get located() { return this.editForm.get('located'); }
    get address() { return this.editForm.get('address'); }

}
