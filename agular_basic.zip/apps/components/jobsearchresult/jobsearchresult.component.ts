import { Component } from '@angular/core';
import { AppComponent } from '../../app.component';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-jobsearchresult',
  templateUrl: './jobsearchresult.component.html',
  styleUrls: ['./jobsearchresult.component.css']
})
export class JobsearchresultComponent extends AppComponent {
  


}
