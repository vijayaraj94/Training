import { Component, Input, EventEmitter, Output, OnInit, Injectable } from '@angular/core';
import { RouterModule, Routes, Router, ActivatedRoute, ParamMap } from '@angular/router';
import { HttpModule } from '@angular/http';
import { AppService } from './app.service';
import { CONST } from './appconstant';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [AppService]
})
export class AppComponent {

  router: any;

  appService: any;

  activeRoutePath: string;

  routing: Object = {};

  pageTitle = 'Home';

  CONST : any;

  constructor(
    activatedRoute: ActivatedRoute,
    router: Router,
    appService: AppService
  ) {
    this.activeRoutePath = activatedRoute.snapshot.url.join('');
    this.router = router;
    this.appService = appService;
    this.CONST = CONST;
  }

  /* [ Get Constant Value ] */
  getConst(c = null) {
    if (c != null) return this.fetchFromObject(CONST, c);
    return CONST;
  }

  /* [ Fetch from Object ] */
  fetchFromObject(obj, prop) {
    if (typeof obj === 'undefined') return false;
    var _index = prop.indexOf('.')
    if (_index > -1) {
      return this.fetchFromObject(obj[prop.substring(0, _index)], prop.substr(_index + 1));
    }
    return obj[prop];
  }

  /* [ Set Route Path ] */
  getRoute(r){
    return '/'+ this.getConst(r);
  }

  /* [ Get Assets Data ] */
  getAssets(u){
    return 'assets/'+ u;
  }

  /* [ Get Active Path ] */
  getActiveClass(p){
    return (this.activeRoutePath === this.getConst(p)) ? 'active' : '';
  }
}
